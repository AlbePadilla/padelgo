<?php $this->layout('layout') ?>

<div class="container">
    
    <h3>El Recurso Que Solicita No Ha Sido Encontrado</h3>
    <p><?= $error ?></p>
</div>