<div class="navigation">
    <a href="<?php echo URL; ?>">HOME</a>
    <a href="<?php echo URL; ?>centros">CENTROS</a>
    <a href="<?php echo URL; ?>actividades">ACTIVIDADES</a>
    <a href="<?php echo URL; ?>alumnos">ALUMNOS</a>    
    <a href="<?php echo URL; ?>tutores">PADRES</a>
    <a href="<?php echo URL; ?>login">LOGIN</a>    
    <a href="<?php echo URL; ?>buscar">BUSCAR</a>
    <a href="<?php echo URL; ?>login/salir">SALIR</a>
</div>