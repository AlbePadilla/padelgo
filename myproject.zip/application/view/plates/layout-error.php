<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1>HTTP Error 404</h1>
    <?= $this->section('content') ?>
</body>
</html>