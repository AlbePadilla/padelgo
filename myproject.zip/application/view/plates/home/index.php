<?php $this->layout('layout') ?>

<div class="container">
	<h2> PRESENTACIÓN </h2>
    <p><?= $presentacion ?></p>
</div>

<div class="container">	
	<h3> OBJETIVOS Y DESARROLLO </h3>
    <p><?= $objetivos ?></p>    
    <p><?= $desarrollo ?></p>
</div>

<div class="container">	
	<h3> GUIA DE USO </h3>
    <p>
    	"Para utilizar esta aplicación, tendrá que registrar un alumno en la base de datos, y posteriormente
    	tendrá que registrarse indicando el Alumno asignado.

    	Para acceder a sus datos puede autenticarse en la seccion LOGIN.
    </p>
</div>

