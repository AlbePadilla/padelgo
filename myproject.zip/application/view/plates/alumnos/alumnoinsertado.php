<?php $this->layout('layout-dos') ?>

<div class="container">
    
    <h2>Gracias por Registrarse!!!</h2>  
	<p>
    <a href="/alumnos/index"><h2>Volver</h2></a>
	</p>

 
</div>